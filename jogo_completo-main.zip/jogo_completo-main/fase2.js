let questions = [
    {
        numb: 1,
        question: "Dica: Refere-se  a uma criança",
        answer: "bebê",

        options: [
            "bêbe",
            "bebê"
        ],
        hint: "A palavra se refere a uma criança."
    },
    {
        numb: 2,
        question: "Dica: É um determinado território social, político e geograficamente delimitado",
        answer: "país",
        options: [
            "páis",
            "país"
        ],
        hint: "Refere-se a determinado território social, política e geograficamente delimitado."
    },
    {
        numb: 3,
        question: "Dica: Aparelho destinado a produzir movimentos ou transformar determinada forma de energia",
        answer: "máquina",
        options: [
            "máquina",
            "maquína"
        ],
        hint: "Utilizada para facilitar o trabalho."
    },
    {
        numb: 4,
        question: "Dica: Se refere a atos ou movimentos'",
        answer: "ações",
        options: [
            "acoés",
            "ações"
        ],
        hint: "Se refere a atos ou movimentos."
    },
    {
        numb: 5,
        question: "Dica: Usado para medir o tempo",
        answer: "relógio",
        options: [
            "relógio",
            "rélogiô"
        ],
        hint: "Usado para medir o tempo."
    },
    {
        numb: 6,
        question: "Dica: Um grupo organizado de soldados",
        answer: "exército",
        options: [
            "exercíto",
            "exército"
        ],
        hint: "Um grupo organizado de soldados."
    },
    {
        numb: 7,
        question: "Dica: Uma bebida popular feita de grãos torrados",
        answer: "café",
        options: [
            "café",
            "cáfe"
        ],
        hint: "Uma bebida popular feita de grãos torrados."
    },
    {
        numb: 8,
        question: "Dica: Refere-se a algo que acontece em pouco tempo",
        answer: "rápida",
        options: [
            "rapída",
            "rápida"
        ],
        hint: "Refere-se a algo que acontece em pouco tempo."
    },
    {
        numb: 9,
        question: "Diva: Recurso natural fundamental para vida",
        answer: "água",
        options: [
            "aguá",
            "água",
        ],
        hint: "Essencial para a vida."
    },
    {
        numb: 10,
        question: "Diva: Utilizada para falar e comer",
        answer: "língua",
        options: [
            "língua",
            "lingua",
        ],
        hint: "Utilizada para falar e comer."
    },
];

    
